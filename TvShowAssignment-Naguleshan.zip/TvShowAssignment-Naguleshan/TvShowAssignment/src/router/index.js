import Vue from "vue";
import VueRouter from "vue-router";
import TvShowDashboard from '@/views/TvShowDashboard.vue';
import TvShowSearch from '@/views/TvShowSearch.vue';
import TvShowDetail from '@/views/TvShowDetail.vue';
Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "TvShowDashboard",
    component: TvShowDashboard
  },
  {
    path: "/search",
    name: "TvShowSearch",
    component: TvShowSearch
  },
  {
      path: "/detail/:id",
      name: "TvShowDetail",
      component: TvShowDetail
  },
  {
    path: "/about",
    name: "About",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/About.vue")
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;
