<template>
  <div class="padding:40px;margin-top:50px;">
    <h1>TVmaze is a community of TV lovers and dedicated contributors that discuss and help maintain tv information on the web.</h1>
  </div>
</template>
