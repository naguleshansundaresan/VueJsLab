<template>
  <v-container fluid>
    <!--Useing data iterator for dashboard list pagination -->
    <v-data-iterator
      :items="tvShowsDashboardList"
      :items-per-page.sync="showsPerPage"
      :page="page"
      hide-default-footer
    >
    <!--passing data iterator items i.e dashboard list as a props to default v-slot-->
      <template v-slot:default="props">
        <div class="home">
          <v-container grid-list-xl>
            <v-layout row>
              <h1>Popular Shows</h1>
            </v-layout>
            <v-layout row align="center">
              <v-flex md4 v-for="(tvShow,index) in props.items" :key="index">
                <v-card width="450" elevation="15" color="cyan darken-2" class="white--text">
                  <v-card-title v-if="tvShow.name">{{tvShow.name}}</v-card-title>
                  <v-img
                    :src="tvShow.image.medium"
                    max-height="400"
                    :contain="true"
                    aspect-ratio="1"
                    v-if="tvShow.image"
                  ></v-img>
                  <v-card-text>
                    <span class="white--text">
                      <b>Rating</b>
                      : {{tvShow.rating.average}}
                    </span>
                    <div>
                      <span class="white--text" v-if="tvShow.genres">
                        <b>Genre</b> :
                        <span
                          class="white--text"
                          v-for="tvShowGenre in tvShow.genres"
                          :key="tvShowGenre"
                        >
                          <v-icon left>mdi-tag</v-icon>
                          {{tvShowGenre}}
                        </span>
                      </span>
                    </div>
                  </v-card-text>
                  <v-card-actions class="justify-center">
                    <v-btn
                      elevation="10"
                      color="cyan darken-2"
                      class="white--text"
                      :href="`detail/${tvShow.id}`"
                    >Explore</v-btn>
                  </v-card-actions>
                </v-card>
              </v-flex>
            </v-layout>
          </v-container>
        </div>
      </template>
<!-- Use v-slot:footer for pagination using data iterator-->
      <template v-slot:footer>
        <v-row class="mt-2" align="center" justify="center">
          <span class="grey--text">Items per page</span>
          <v-menu offset-y>
            <template v-slot:activator="{ on }">
              <v-btn dark text color="primary" class="ml-2" v-on="on">
                {{ showsPerPage }}
                <v-icon>mdi-chevron-down</v-icon>
              </v-btn>
            </template>
            <v-list>
              <v-list-item
                v-for="(number, index) in showsPerPageArray"
                :key="index"
                @click="updateShowsPerPage(number)"
              >
                <v-list-item-title>{{ number }}</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>

          <v-spacer></v-spacer>

          <span class="mr-4 grey--text">Page {{ page }} of {{ numberOfPages }}</span>
          <v-btn fab dark color="blue darken-3" class="mr-1" @click="formerPage">
            <v-icon>mdi-chevron-left</v-icon>
          </v-btn>
          <v-btn fab dark color="blue darken-3" class="ml-1" @click="nextPage">
            <v-icon>mdi-chevron-right</v-icon>
          </v-btn>
        </v-row>
      </template>
    </v-data-iterator>
  </v-container>
</template>

<script>
import { getAllShows } from "@/services/show.service.js";
export default {
  name: "TvShowDashboard",
  data() {
    return {
      tvShowsList: [],
      tvShowsDashboardList: [],
      showsPerPage: 9,
      page: 1,
      showsPerPageArray: [6, 9, 12]
    };
  },
  methods: {
    //Called when the instance of the TvShowDashboard component is created 
    async getAllTvShows() {
      getAllShows()
        .then(response => {
          this.tvShowsList = response.data;
          this.tvShowsList.forEach(show => {
            //update tvShowsDashboardList list which contains only shows with average rating
            if (show.rating.average) {
              this.tvShowsDashboardList.push(show);
            }
          });
          this.sortTvShow();

        })
        .catch(error => {
          alert(error);
        });
    },
    sortTvShow() {
          this.tvShowsDashboardList.sort((tvShow1, tvShow2) => {
            return tvShow2.rating.average - tvShow1.rating.average;
          });
    },
    nextPage() {
      if (this.page + 1 <= this.numberOfPages) this.page += 1;
    },
    formerPage() {
      if (this.page - 1 >= 1) this.page -= 1;
    },
    updateShowsPerPage(number) {
      this.showsPerPage = number;
    }
  },
  computed: {
    numberOfPages() {
      return Math.ceil(this.tvShowsDashboardList.length / this.showsPerPage);
    }
  },
  created() {
    this.getAllTvShows();
  }
};
</script>
