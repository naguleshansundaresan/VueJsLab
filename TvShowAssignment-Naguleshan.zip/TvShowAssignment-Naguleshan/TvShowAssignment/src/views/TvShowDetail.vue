<template>
    <!--If show details are found for relevant show id display the show details-->
  <v-container grid-list-xl style="background-color:lightGray">
    <v-layout row align="center" justify="center">
      <v-flex md6>
        <v-row justify="center">
          <h1 v-if="tvShowInfo.name">{{tvShowInfo.name}}</h1>
        </v-row>

        <v-img
          :src="tvShowInfo.image.original"
          max-height="450"
          :contain="true"
          v-if="tvShowInfo.image"
          style="margin-top:20px;margin-bottom:10px;"
        ></v-img>
        <v-img
          v-else
          src="@/assets/NoImageAvailable.png"
          style="margin-top:20px;margin-bottom:10px;"
          aspect-ratio="1"
        ></v-img>
      </v-flex>

      <v-flex md6>
        <v-card
          elevation="15"
          style="background-color:lightGray;margin-top:50px;margin-bottom:10px;padding:20px;"
        >
          <v-card-title class="black--text">
            <b>Show Info</b>
          </v-card-title>
          <v-card-text>
            <v-row>
              <span class="black--text" v-if="tvShowInfo.summary" v-html="tvShowInfo.summary"></span>
            </v-row>
            <v-row v-if="tvShowInfo.rating">
              <span class="black--text" v-if="tvShowInfo.rating.average">
                <p>
                  <b>Rating :</b>
                </p>
              </span>
              <span v-else>No Rating</span>
              <v-rating
                v-model="tvShowInfo.rating.average"
                color="amber"
                dense
                half-increments
                readonly
                size="14"
                length="10"
              >{{tvShowInfo.rating.average}}</v-rating>
            </v-row>
            <v-row>
              <div class="black--text" v-if="tvShowInfo.genres">
                <b>Genre</b> :
                <span id = "span-genre"
                  class="black--text"
                  v-for="tvShowGenre in tvShowInfo.genres"
                  :key="tvShowGenre"
                >
                  <v-icon left>mdi-tag</v-icon>
                  {{tvShowGenre}}
                </span>
              </div>
            </v-row>
            <v-row>
              <span class="black--text" v-if="tvShowInfo.language">
                <b>Language</b>
                : {{tvShowInfo.language}}
              </span>
            </v-row>
            <v-row>
              <div class="black--text" v-if="tvShowInfo.schedule">
                <b>Schedule</b> :
                <span
                  class="black--text"
                  v-for="tvShowSchedule in tvShowInfo.schedule.days"
                  :key="tvShowSchedule"
                >
                  {{tvShowSchedule}}
                  <span v-if="tvShowInfo.schedule.time"> at {{tvShowInfo.schedule.time}}</span>
                </span>
              </div>
            </v-row>
            <v-row>
              <span class="black--text" v-if="tvShowInfo.status">
                <b>Status</b>
                : {{tvShowInfo.status}}
              </span>
            </v-row>
            <v-row>
              <span class="black--text" v-if="tvShowInfo.premiered">
                <b>Premiered on</b>
                : {{tvShowInfo.premiered}}
              </span>
            </v-row>
            <v-row>
              <span class="black--text" v-if="tvShowInfo.officialSite">
                <b>Official Site</b> :
                <a :href="tvShowInfo.officialSite">{{tvShowInfo.officialSite}}</a>
              </span>
            </v-row>
          </v-card-text>
        </v-card>
      </v-flex>
    </v-layout>
    <!--If cast details are found display the cast details in a card-->
    <v-container grid-list-xl v-if="tvShowCast" style="padding:40px;margin-top:50px;">
      <h1>Cast</h1>
      <br />
      <v-layout row>
        <v-flex md4 v-for="(cast,index) in tvShowCast" :key="index">
          <v-card
            class="d-inline-block lightGray"
            elevation="15"
            outlined
            :href="cast.person.url"
            target="_blank"
            style="background-color:lightGray;padding:20px;"
            v-if="cast.person.url"
          >
            <v-container>
              <v-row>
                <v-col cols="auto">
                  <v-img
                    height="200"
                    width="200"
                    :src="cast.person.image.medium"
                    v-if="cast.person.image"
                  ></v-img>
                  <v-img v-else src="@/assets/NoImageAvailable.png"></v-img>
                  <p align="center" v-if="cast.person.name">
                    <b>{{cast.person.name}}</b>
                  </p>
                  <p align="center" v-if="cast.person.birthday">
                    <b>DOB</b>
                    : {{cast.person.birthday}}
                  </p>
                </v-col>
              </v-row>
            </v-container>
          </v-card>
        </v-flex>
      </v-layout>
    </v-container>
  </v-container>
</template>

<script>
import { getShowInfo } from "@/services/show.service.js";
export default {
  name: "TvShowDetail",
  data() {
    return {
      tvShowId: this.$route.params.id,
      tvShowInfo: [],
      tvShowCast: []
    };
  },
  methods: {
    async getTvShowInfo() {
      //api call to fetch data about the relevant show by id 
      await getShowInfo(this.tvShowId)
        .then(response => {
          this.tvShowInfo = response.data;  
        })
        .catch();
        this.getCastInfo();
    },
    getCastInfo() {
      //If cast information available , get the cast info
      if (this.tvShowInfo._embedded) {
            this.tvShowCast = this.tvShowInfo._embedded.cast;
          }
    }
  },
  created() {
    //Fetching show information of the corresponding show id during created life cycle hook
    this.getTvShowInfo();
  }
};
</script>