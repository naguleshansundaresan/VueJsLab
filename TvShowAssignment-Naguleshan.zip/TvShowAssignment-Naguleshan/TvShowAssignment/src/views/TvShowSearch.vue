<template>
  <v-container grid-list-xl>
    <v-layout row>
      <v-flex md6>
        <input type="text" placeholder="Search Shows" v-model="searchedTvShow" />
        <v-btn height="25" id="search-btn" color="cyan darken-2" class="white--text" @click="getSearchedTvShow">
          <v-icon>mdi-database-search</v-icon>Search
        </v-btn>
      </v-flex>
    </v-layout>
    <v-layout row align="center">
      <v-flex md4 v-for="(tvShow,index) in tvShowSearchList" :key="index">
        <v-card
          width="450"
          elevation="15"
          color="cyan darken-2"
          class="white--text"
          v-if="tvShow.show"
        >
          <v-card-title v-if="tvShow.show.name">{{tvShow.show.name}}</v-card-title>
          <v-img
            :src="tvShow.show.image.medium"
            max-height="400"
            :contain="true"
            aspect-ratio="1"
            v-if="tvShow.show.image"
          ></v-img>
          <v-img v-else src="@/assets/NoImageAvailable.png" aspect-ratio="1"></v-img>
          <v-card-text>
            <span class="white--text" v-if="tvShow.show.rating.average">
              <b>Rating</b>
              : {{tvShow.show.rating.average}}
            </span>
            <div>
              <span class="white--text" v-if="tvShow.show.genres.length>0">
                <b>Genre</b> :
                <span
                  class="white--text"
                  v-for="tvShowGenre in tvShow.show.genres"
                  :key="tvShowGenre"
                >
                  <v-icon left>mdi-tag</v-icon>
                  {{tvShowGenre}}
                </span>
              </span>
            </div>
          </v-card-text>
          <v-card-actions class="justify-center">
            <v-btn
              elevation="10"
              color="cyan darken-2"
              class="white--text"
              :href="`detail/${tvShow.show.id}`"
            >Explore</v-btn>
          </v-card-actions>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
import { getShowsByName } from "@/services/show.service.js";
export default {
  name: "TvShowSearch",
  data() {
    return {
      searchedTvShow: "",
      tvShowSearchList: []
    };
  },
  methods: {
    //Function triggered when search button is clicked
    getSearchedTvShow() {
      //Fetch relevant shows list based on searched string
      getShowsByName(this.searchedTvShow)
        .then(response => {
          this.tvShowSearchList = response.data;
        })
        .catch();
    }
  }
};
</script>