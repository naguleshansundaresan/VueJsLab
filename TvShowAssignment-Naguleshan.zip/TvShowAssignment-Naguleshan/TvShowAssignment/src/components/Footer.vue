<template>
  <v-footer  dark>
    <v-col class="white--text" cols="12"  align="center">
    Copyright &copy; 2020, TvMaze. All Rights Reserved.
    </v-col>
  </v-footer>
</template>

<script>
export default {
  name: "AppFooter"
}
</script>
