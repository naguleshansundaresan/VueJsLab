<template>
  <v-app style="background-color:lightGray">
    <AppHeader></AppHeader>
    <v-content>
      <router-view/>
    </v-content>
    <footer>
    <AppFooter></AppFooter>
    </footer>
  </v-app>
</template>

<script>
import AppHeader from '@/components/Header.vue';
import AppFooter from '@/components/Footer.vue';
export default {
  name: "App",

  components: {
    AppHeader,
    AppFooter
  },

};
</script>
