import axios from "axios";
export const id = 123;

export const getShowsByName = (showName) => {
    return axios.get(`http://api.tvmaze.com/search/shows?q=${showName}`);
}


export const getAllShows = () => {
    return axios.get("http://api.tvmaze.com/shows");
}

export const getShowInfo = (showId) => {
    return axios.get(`http://api.tvmaze.com/shows/${showId}?embed=cast`);
}

