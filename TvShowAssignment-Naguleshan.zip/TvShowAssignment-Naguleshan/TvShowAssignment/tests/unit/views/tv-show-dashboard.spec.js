import { shallowMount } from '@vue/test-utils';
import TvShowDashboard from '@/views/TvShowDashboard.vue';
import Vuetify from "vuetify";
import Vue from "vue";
import { tvAllShowMockData } from './tv-show-data.fixture.js';
describe('From TvShowSearch Component ', () => {
    let tvShowDashboardWrapper;
    beforeEach(() => {
        Vue.use(Vuetify);
        tvShowDashboardWrapper = shallowMount(TvShowDashboard, {
            Vue,
            data() {
                return {
                    tvShowsDashboardList: [{
                        "id": 169,
                        "name": "Breaking Bad",
                        "rating": { "average": 9.3 },
                        "genres": ["Crime", "Drama", "Thriller"]
                    },
                    {
                        "id": 249,
                        "name": "Sherlock",
                        "rating": { "average": 9.5 },
                        "genres": ["Thriller", "Crime"]
                    }],
                    showsPerPage: 9,
                    page: 1,
                    showsPerPageArray: [6, 9, 12]
                }
            },

        })
    });
    afterEach(() => {
        tvShowDashboardWrapper.destroy();
    });

    it('is a Vue instance', () => {
        expect(tvShowDashboardWrapper.isVueInstance).toBeTruthy();
    });

    it('it should have a <v-container-stub>', () => {
        expect(tvShowDashboardWrapper.html()).toContain("v-container-stub")
    });

    it("should test next page function", () => {
        let expected = 2;
        tvShowDashboardWrapper.vm.tvShowsDashboardList = tvAllShowMockData;
        tvShowDashboardWrapper.vm.nextPage();
        expect(tvShowDashboardWrapper.vm.page).toEqual(expected);
    });

    it("should test former page function", () => {
        let expected = 1;
        tvShowDashboardWrapper.vm.page = 2;
        tvShowDashboardWrapper.vm.formerPage();
        expect(tvShowDashboardWrapper.vm.page).toEqual(expected);
    });


    it("should test updateShowsPerPage page function", () => {
        let expected = 5;
        tvShowDashboardWrapper.vm.updateShowsPerPage(5);
        expect(tvShowDashboardWrapper.vm.showsPerPage).toEqual(expected);
    });

    it("should test sortTvShow function", () => {
        let expected = [{
            "id": 249,
            "name": "Sherlock",
            "rating": { "average": 9.5 },
            "genres": ["Thriller", "Crime"]
        },
        {
            "id": 169,
            "name": "Breaking Bad",
            "rating": { "average": 9.3 },
            "genres": ["Crime", "Drama", "Thriller"]
        }
        ]
        tvShowDashboardWrapper.vm.sortTvShow();
        expect(tvShowDashboardWrapper.vm.tvShowsDashboardList).toEqual(expected);
    });


    it('should find div', () => {
        expect(tvShowDashboardWrapper.html()).toContain("div")
    });


});