import { shallowMount } from '@vue/test-utils';
import TvShowSearch from '@/views/TvShowSearch.vue';
import Vuetify from "vuetify";
import Vue from "vue";
import { tvMockSearchData } from './tv-show-data.fixture.js';
describe('From TvShowSearch Component ', () => {
    let tvShowSearchWrapper;
    beforeEach(() => {
        Vue.use(Vuetify);
        tvShowSearchWrapper = shallowMount(TvShowSearch, {
            Vue,
            data() {
                return {
                    searchedTvShow: "Breaking Bad",
                    tvShowSearchList: tvMockSearchData
                }
            }
        })
    });
    afterEach(() => {
        tvShowSearchWrapper.destroy();
    });

    it('is a Vue instance', () => {
        expect(tvShowSearchWrapper.isVueInstance).toBeTruthy();
    });

    it('it should have a <v-container-stub>', () => {
        expect(tvShowSearchWrapper.html()).toContain("v-container-stub")
    });

    it('should find v-layout', () => {
        expect(tvShowSearchWrapper.html()).toContain("v-layout-stub")
    });

    it('it should have a <v-card-stub>', () => {
        expect(tvShowSearchWrapper.html()).toContain("v-card-stub")
    });


    it('it should have a <v-card-actions-stub>', () => {
        expect(tvShowSearchWrapper.html()).toContain("v-card-actions-stub")
    });

    it('it should have a <v-card-text-stub>', () => {
        expect(tvShowSearchWrapper.html()).toContain("v-card-text-stub")
    });

    it('it should have a <v-card-title-stub>', () => {
        expect(tvShowSearchWrapper.html()).toContain("v-card-title-stub")
    });

    it('should find v-img', () => {
        expect(tvShowSearchWrapper.html()).toContain("v-img-stub")
    });


    it('should find v-icon', () => {
        expect(tvShowSearchWrapper.html()).toContain("v-icon-stub")
    });

    it('should find v-flex', () => {
        expect(tvShowSearchWrapper.html()).toContain("v-flex-stub")
    });

    it('should find span', () => {
        expect(tvShowSearchWrapper.html()).toContain("span")
    });

    it('should find b', () => {
        expect(tvShowSearchWrapper.html()).toContain("b")
    });

    it('should find div', () => {
        expect(tvShowSearchWrapper.html()).toContain("div")
    });

    it('should find v-btn', () => {
        expect(tvShowSearchWrapper.html()).toContain("v-btn-stub")
    });

    it('should find data', () => {
        expect(tvShowSearchWrapper.vm.searchedTvShow).toBe("Breaking Bad");
        expect(tvShowSearchWrapper.vm.tvShowSearchList).toBe(tvMockSearchData);
    });

});