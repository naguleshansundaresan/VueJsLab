import { shallowMount } from '@vue/test-utils';
import TvShowDetail from '@/views/TvShowDetail.vue';
import Vuetify from "vuetify";
import Vue from "vue";
import { tvMockShowData, tvShowCastMockData } from './tv-show-data.fixture.js';
describe('From TvShowDetail Component ', () => {
    let tvShowDetailWrapper;
    beforeEach(() => {
        Vue.use(Vuetify);
        tvShowDetailWrapper = shallowMount(TvShowDetail, {
            Vue,
            mocks: {
                $route: {
                    params: { "id": "47731" },
                }
            },
            data() {
                return {
                    tvShowId: "",
                    tvShowInfo: tvMockShowData,
                    tvShowCast: tvShowCastMockData
                }
            }
        })
    });
    afterEach(() => {
        tvShowDetailWrapper.destroy();
    });

    it('is a Vue instance', () => {
        expect(tvShowDetailWrapper.isVueInstance).toBeTruthy();
    });

    it('it should have a <v-container-stub>', () => {
        expect(tvShowDetailWrapper.html()).toContain("v-container-stub")
    });

    it('should find v-layout', () => {
        expect(tvShowDetailWrapper.html()).toContain("v-layout-stub")
    });

    it('it should have a <v-card-stub>', () => {
        expect(tvShowDetailWrapper.html()).toContain("v-card-stub")
    });

    it('it should have a <v-card-text-stub>', () => {
        expect(tvShowDetailWrapper.html()).toContain("v-card-text-stub")
    });

    it('it should have a <v-card-title-stub>', () => {
        expect(tvShowDetailWrapper.html()).toContain("v-card-title-stub")
    });

    it('it should have a <br>', () => {
        expect(tvShowDetailWrapper.html()).toContain("br")
    });

    it('should find v-img', () => {
        expect(tvShowDetailWrapper.html()).toContain("v-img-stub")
    });


    it('should find v-rating', () => {
        expect(tvShowDetailWrapper.html()).toContain("v-rating-stub")
    });

    it('should find v-flex', () => {
        expect(tvShowDetailWrapper.html()).toContain("v-flex-stub")
    });

    it('should find v-col', () => {
        expect(tvShowDetailWrapper.html()).toContain("v-row-stub")
    });

    it('should find v-row', () => {
        expect(tvShowDetailWrapper.html()).toContain("v-col-stub")
    });

    it('should find span tag', () => {
        expect(tvShowDetailWrapper.html()).toContain("span")
    });

    it('should find div tag', () => {
        expect(tvShowDetailWrapper.html()).toContain("div")
    });

    it('should find p tag', () => {
        expect(tvShowDetailWrapper.html()).toContain("p")
    });

    it('should find b tag', () => {
        expect(tvShowDetailWrapper.html()).toContain("b")
    });

    it('should find anchor tag', () => {
        expect(tvShowDetailWrapper.html()).toContain("a")
    });

    it('should find h1 tag', () => {
        expect(tvShowDetailWrapper.html()).toContain("h1")
    });

    it('should find span genre tag', () => {
        expect(tvShowDetailWrapper.find('#span-genre'))
    });

    it("initialize function should be called on create", async () => {
        const spyinit = jest.spyOn(tvShowDetailWrapper.vm, "getTvShowInfo");
        setTimeout(() => {
            expect(spyinit).toHaveBeenCalled();
            expect(tvShowDetailWrapper.vm.getTvShowInfo).toHaveBeenCalled();
            expect(tvShowDetailWrapper.vm.getCastInfo).toHaveBeenCalled();
        });

    });

    it("it should assign values to variable cast", () => {
        let expected = tvShowCastMockData;
        tvShowDetailWrapper.vm.tvShowInfo = { _embedded: { cast: tvShowCastMockData } };
        tvShowDetailWrapper.vm.getCastInfo();
        expect(tvShowDetailWrapper.vm.tvShowCast).toEqual(expected);
    });

});