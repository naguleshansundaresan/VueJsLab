import {shallowMount} from '@vue/test-utils';
import AppHeader from '@/components/Header.vue';
import Vuetify from "vuetify";
import Vue from "vue";
import { routes } from '@/router/index';
import VueRouter from 'vue-router';
describe('From Header Component ',() => {
    let headerWrapper;
    const router = new VueRouter({ routes });
beforeEach(() => {
Vue.use(Vuetify);
headerWrapper = shallowMount(AppHeader,{
     Vue,
    router,
    attachToDocument: true,
})
});
afterEach(() => {
    headerWrapper.destroy();
  });
 
  it('is a Vue instance', () => {
    expect(headerWrapper.isVueInstance).toBeTruthy();
  });

  it('it should have a <v-app-bar-stub>', () => {
    expect(headerWrapper.html()).toContain("v-app-bar-stub")
});

it('it should have a <v-app-bar-nav-icon-stub>', () => {
    expect(headerWrapper.html()).toContain("v-app-bar-nav-icon-stub")
});

it('should find v-toolbar', () => {
    expect(headerWrapper.html()).toContain("v-toolbar-stub")
});

it('it should have a <v-navigation-drawer-stub>', () => {
    expect(headerWrapper.html()).toContain("v-navigation-drawer-stub")
});

it('should find v-list', () => {
    expect(headerWrapper.html()).toContain("v-list-stub")
});


it('should find v-icon', () => {
    expect(headerWrapper.html()).toContain("v-icon-stub")
});


});