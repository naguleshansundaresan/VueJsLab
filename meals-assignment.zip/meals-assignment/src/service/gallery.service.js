import axios from "axios";
const getAllImage = () =>{
    return axios.get(`https://picsum.photos/v2/list`);
}

const getImagesPerPage = (pageNo, noOfItems) =>{
    return axios.get(`https://picsum.photos/v2/list?page=${pageNo}&limit=${noOfItems}`);
}

const getCurrentPage = (pageNo) => {
    return axios.get(`https://picsum.photos/v2/list?page=${pageNo}`);
}

const getImage = (src) => {
    return axios.get(`${src}`);
}

export {
    getAllImage,
    getImagesPerPage,
    getCurrentPage,
    getImage
}