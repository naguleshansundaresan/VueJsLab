<template>
  <v-app-bar app dark>
    <v-app-bar-nav-icon @click.stop="sidebar =!sidebar" class="hidden md and up"></v-app-bar-nav-icon>
    <v-toolbar>
      <v-toolbar-title>Lorem Image Gallery</v-toolbar-title>
    </v-toolbar>
    <v-spacer></v-spacer>
    <v-navigation-drawer v-model="sidebar" app absolute temporary>
      <v-list>
        <v-list-item v-for="item in menuItems" :key="item.title" :to="item.path">
          <v-list-item-title>{{ item.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
  </v-app-bar>
</template>

<script>
export default {
  name: "AppHeader",
  data() {
    return {
      sidebar: false,
      menuItems: [
        { title: "Home", path: "/" },
        { title: "Gallery", path: "/gallery" },
        { title: "About", path: "/about" }
      ]
    };
  }
};
</script>

<style scoped>
.v-navigation-drawer {
  top: 50px;
}
</style>
