<template>
  <v-container>
    <v-layout>
      <v-card class="mx-auto" width="350px">
        <v-img :src="downloadUrl" placeholder="nature" alt="Lorem Award Picture" height="400px"></v-img>
        <v-card-title>{{author}}</v-card-title>
        <v-card-actions class="justify-center">
          <v-btn-toggle>
            <v-btn @click="downloadImage(downloadUrl)">download</v-btn>
            <v-btn @click="exploreClick(url)">Explore</v-btn>
          </v-btn-toggle>
        </v-card-actions>
      </v-card>
    </v-layout>
  </v-container>
</template>

<script>
import { getImage } from "../service/gallery.service.js";
export default {
  name: "AppCard",
  props: {
    author: {
      type: String,
      required: true
    },
    url: {
      type: String,
      required: true
    },
    downloadUrl: {
      type: String,
      required: true
    }
  },
  methods: {
    downloadImage(downloadUrl) {
      getImage(downloadUrl).then(response => {
        var fileURL = window.URL.createObjectURL(new Blob([response.data]));
        var fileLink = document.createElement("a");
        fileLink.href = fileURL;
        fileLink.setAttribute("download", "file.png");
        document.body.appendChild(fileLink);
        fileLink.click();
      });
    },
    exploreClick(url) {
      window.open(url, "_blank");
    }
  }
};
</script>