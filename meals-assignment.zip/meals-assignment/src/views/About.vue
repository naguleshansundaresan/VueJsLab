<template>
  <v-container fill-height fluid>
    <v-row align="center" justify="center">
      <v-col cols="12" md="4">
        <h1>Explore the beauty of the world in photography!!!</h1>
      </v-col>
    </v-row>
  </v-container>
</template> 

<!--
<template>
  <v-container fill-height fluid>
    <v-row align="center" justify="center">
      <v-col cols="12" md="4">
        <h1>Explore the beauty of the world in photography!!!</h1>
        <h3>{{name}}</h3>
        <h2>{{changeName}}</h2>
        
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name : 'About',
  data() {
    return{
    name : "hello"
    }
  },
  computed: {
    
    changeName: () => {
      // console.log(this.abc);
      return this.name.reverse();
    } 
  }
}
</script>
-->