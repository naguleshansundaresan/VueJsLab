<template>
  <div>
    <v-container class="spacing-playground py-0 px-2">
      <v-row align="center">
        <v-col class="d-flex" cols="12" sm="6">
          <v-select :items="items" @change="itemsPerPage" v-model="selectedNumOfItem"></v-select>
        </v-col>
      </v-row>
      <v-row>
        <v-col class="v-flex" cols="12" md="4" v-for="(item,index) in imageList" :key="index">
          <AppCard :author="item.author" :downloadUrl="item.download_url" :url="item.url"></AppCard>
        </v-col>
      </v-row>
      <v-row justify="center" class="pr-4">
        <v-col cols="12" md="4">
          <div class="pagination-buttons" justify="center">
            <v-btn @click="getPreviousPageImages">Previous</v-btn>
            <v-btn @click="getNextPageImages">Next</v-btn>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import AppCard from "../components/Card.vue";
import { getAllImage, getImagesPerPage } from "../service/gallery.service.js";
export default {
  name: "Gallery",
  components: {
    AppCard
  },
  data() {
    return {
      imageList: [],
      selectedNumOfItem: 0,
      items: [0, 6, 9, 12, 15],
      pageNo: 1,
      allImageList: []
    };
  },
  methods: {
    async itemsPerPage() {
      getImagesPerPage(this.pageNo, this.selectedNumOfItem).then(resp => {
        this.imageList = resp.data;
      });
    },
    getNextPageImages() {
      this.pageNo = this.pageNo + 1;
      getImagesPerPage(this.pageNo, this.selectedNumOfItem).then(resp => {
        this.imageList = resp.data;
      });
    },
    getPreviousPageImages() {
      this.pageNo = this.pageNo - 1;
      if (this.pageNo > 1) {
        getImagesPerPage(this.pageNo, this.selectedNumOfItem).then(resp => {
          this.imageList = resp.data;
        });
      }
    }
  },
  mounted() {
    getAllImage().then(resp => {
      this.allImageList = resp.data;
    });
  }
};
</script>

<style scoped>
.v-card__actions .v-btn-toggle .v-btn {
  margin-right: 10;
}
</style>