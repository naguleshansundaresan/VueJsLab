<template>
  <div>
    <v-container fluid>
      <v-card class="mt-12 mx-auto" max-width="400">
        <v-img
          src="https://picsum.photos/200/300"
          placeholder="nature"
          alt="Lorem Award Picture"
          height="400px"
        >
          <v-card-title>Lorem Pictures</v-card-title>
        </v-img>
        <v-card-actions class="justify-center"></v-card-actions>
      </v-card>
    </v-container>
  </div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {
      url: ""
    };
  }
};
</script>
