<template>
  <v-app>
    <AppHeader></AppHeader>
    <v-content>
      <router-view />
    </v-content>
  </v-app>
</template>

<script>
import AppHeader from "../src/components/Header.vue";

export default {
  name: "App",

  components: {
    AppHeader
  }
};
</script>
