import { shallowMount, createLocalVue } from '@vue/test-utils';
import about from '@/views/About.vue';
import Vuetify from "vuetify";
import Vue from "vue";
 
describe('In About Component', () => {
  let appWrapper;
 
  beforeEach(() => {
    const localVue = createLocalVue(); 
    Vue.use(Vuetify);
    appWrapper = shallowMount(about, {
      localVue,
      Vue
    });
  });
 //Explore the beauty of the world in photography!!!
  afterEach(() => {
    appWrapper.destroy();
  });
 
  it('is a Vue instance', () => {
    expect(appWrapper.isVueInstance).toBeTruthy();
  });

  it('about.vue text content', () => {
      expect(appWrapper.text()).toMatch('Explore the beauty of the world in photography!!!');
  });

  it('it should have a div element with class="container"', () => {
    expect(appWrapper.html()).toContain("v-container");
  });

});
