
<template>
    <body>
        <!--ascending descending sort based on price in array of products object -->
        <hr>
        <h1>Online Mobile Purchase</h1>
        <table>
            <tr>
                <td>Sort By Price:</td>
                <td>
                    <select v-model="sortOrder" @click="sortByPrice">
                    <option value="Ascending">Low to High</option>
                    <option value="Descending">High to Low</option>
                    </select>
                </td>    
            </tr>
            <tr>
            <tr>
                <td>
                    <b>Product :</b>
                </td>
                <td>    
                    <select v-model="selectedProduct" id="productId">
                    <option v-for ="(product,index) in productList" :key='index'>{{product.name}} Rs.{{product.price}}</option>
                    </select>
                </td>
                <tr>
                <td>
                    <button type="submit" value="Submit" @click="display">Buy Now</button>
                </td>
            </tr>   
            <!--</tr>
                <ul>
                    <li v-for ="(product,index) in productList" :key='index'>{{product}}</li>
                </ul>
                                <td>
                    <button @click="clearValues">Reset</button>                    
                </td>
            </tr>-->
        </table> 
    </body>
</template>

<script>
export default {
    name:"Sort",
    data(){
        return{
            sortOrder: "",
            selectedProduct: {name:"",price:0},
            productList: [{name:"Nokia",price:30000},
                            {name:"IPhone",price:90000},
                            {name:"HCL",price:17000},
                            {name:"Moto",price:22000},
                            {name:"OnePlus",price:45000},
                            {name:"MicroMax",price:4000},
                            {name:"BlackBerry",price:32000},
                            {name:"Xiaomi",price:15000}]
        };
    },
    methods:{
        sortByPrice() {
          
            if(this.sortOrder=="Ascending")
            {
                this.productList.sort(function(a, b){return a.price-b.price});
                 
            }
            else if(this.sortOrder=="Descending")
            {
                this.productList.sort(function(a, b){return b.price-a.price});
            }
        },
        display() {
             confirm(this.selectedProduct);
           }
    }
}
</script>

