<template>
    <div id="formView" align="centre">
        <hr>
        <h1>Register City!!!</h1>
        <table>
            <tr>    
                <td><b>State :</b></td>
                <td><select v-model="selectedState" @change="changeCityList" id="stateId">
                    <option v-for="(state,index) in stateList" :key='index'>{{state}}</option>
                    </select>
                </td>    
            </tr>
            <tr>
                <td>
                    <b>City :</b>
                </td>
                <td>    
                    <select v-model="selectedCity" id="cityId">
                    <option v-for ="(city,index) in cityList" :key='index'>{{city}}</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>
                    <button type="submit" value="Submit" @click="display">Register</button>
                </td>
            </tr>   
         </table>
    </div>
</template>     

<script>
export default {
    name: "City",
    data() {
        return{
        stateList : ["Andhra Pradesh","Karnataka","Kerala","Maharashtra","TamilNadu"],
        stateCityList : { AndhraPradesh:["Visakhapatnam","Vijayawada","Tirupati","Kakinada"],
                          Karnataka:["Bangalore","Davangere","Mangalore","Udupi"],
                          Kerala:["Kochi","Munnar","Thrissur","Alappuzha"],
                          Maharashtra:["Mumbai","Pune","Nagpur","Thane"],
                          TamilNadu:["Chennai","Salem","Trichy","Tanjore"]
        },
        cityList : [],
        selectedState : "",
        selectedCity : ""
        };
    },
    methods: {
        changeCityList() {
            if(this.selectedState == "Andhra Pradesh")
            { this.cityList = this.stateCityList.AndhraPradesh;}
            else if(this.selectedState == "Karnataka")
            { this.cityList = this.stateCityList.Karnataka;}
            else if(this.selectedState == "Kerala")
            { this.cityList = this.stateCityList.Kerala;}
            else if(this.selectedState == "Maharashtra")
            { this.cityList = this.stateCityList.Maharashtra;}
            else if(this.selectedState == "TamilNadu")
            { this.cityList = this.stateCityList.TamilNadu;}
        },
        display() {
             confirm("You have selected " + this.selectedCity + " city from " + this.selectedState + " state.");
         }
    }
        
}
</script>