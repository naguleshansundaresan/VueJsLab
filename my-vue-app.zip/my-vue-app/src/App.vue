<template>
  <div id="app">
    <Form1/>
    <Task2/>
  </div>
</template>

<script>
//import HelloWorld from "./components/HelloWorld.vue";
import Form1 from "./components/Form1.vue";
import Task2 from "./components/Task2.vue";
export default {
  name: "App",
  components: {
   // HelloWorld,
    Form1,
    Task2
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
