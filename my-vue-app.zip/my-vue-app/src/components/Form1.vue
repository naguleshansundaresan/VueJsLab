<template>
    <div id="formView" align="centre">
        
        <h1>Product Details</h1>
        <form>
        <table>
            <tr>    
                <td><b>Category :</b></td>
                <td><select v-model="selectedCategory" @change="changeList" id="categoryId">
                    <option v-for="(category,index) in categoryList" :key='index'>{{category}}</option>
                    </select>
                </td>    
            </tr>
            <tr>
                <td>
                    <b>Product :</b>
                </td>
                <td>    
                    <select v-model="selectedProduct" id="productId">
                    <option v-for ="(product,index) in productList" :key='index'>{{product}}</option>
                    </select>
                </td>
            </tr>
            <tr>    
                <td>
                    <b>Quantity :</b>
                </td>
                <td>    
                    <input type="text" v-model="quantity" @change="calculatePrice" id="quantityId">
                </td>
            </tr>
            <tr>
                <td>
                    <b>TotalPrice :</b>
                </td>
                <td>
                    <input type="text" v-model="totalPrice" id="totalPriceId" readonly>

                </td>
            </tr>    
            <tr>
                <td>
                    <button type="submit" value="Submit" @click="display">Submit</button>
                </td>
                <td>
                    <button @click="clearValues">Reset</button>                    
                </td>
            </tr>   

        </table>
        </form>
    </div>
</template>

<script>
export default {
    name: "Form1",
    data() {
        return{
            categoryList : ["Electronics","Grocery"],
            productList : [],
            selectedCategory : "",
            selectedProduct : "",
            quantity : 0,
            totalPrice : 0
        };
    },
    methods: {
        changeList(){
            console.log(this.selectedCategory);
            if(this.selectedCategory == "Electronics")
            {this.productList = ["Television","Laptop","Phone"];}
            else
            {this.productList = ["Soap","Powder"];}
        },
        calculatePrice()
        {
            if(this.selectedCategory == "Electronics")
            {
                if(this.selectedProduct == "Television")
                    this.totalPrice = 20000 * this.quantity;
            
                else if(this.selectedProduct == "Laptop")
                    this.totalPrice = 30000 * this.quantity;

                else if(this.selectedProduct == "Phone")
                    this.totalPrice = 10000 * this.quantity;}
            else
            {
                if(this.selectedProduct == "Soap")
                    this.totalPrice = 40 * this.quantity;
            
                else if(this.selectedProduct == "Powder")
                    this.totalPrice = 90 * this.quantity;
        }
        },
        display(){
            confirm(" Category : " + this.selectedCategory + " Product : " + this.selectedProduct + " Quantity : " + this.quantity + " TotalPrice : " + this.totalPrice   );
        },
        clearValues()
        {
            this.totalPrice = 0;
            this.quantity = 0;
            this.selectedProduct = "";
            this.selectedCategory = "";
        }
    }

}
</script>

<style scoped>
div{
    color :black;
    background-color: blue;
}
</style>
