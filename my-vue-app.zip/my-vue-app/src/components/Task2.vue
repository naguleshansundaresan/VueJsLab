<template>
    <div>
        <hr>
        <h1>SkillSet Management</h1>
        <table align = "centre">
        <tr>
            <td>
            <input type="text" v-model="data">
            </td>
            <td>
            <button @click="addToList">Add</button><br>
            </td>
        </tr>
        <tr>
            <td>
            <ul>           
            <li v-for="(currData,index) in dataList" :key="index" >
            <input type = "checkbox" name="checkBox" @change="selectedIndexes(index)">{{currData}}
            </li>            
            </ul>
            </td>
            <td>
            <button @click="removeFromList">Remove</button>
            </td>
        </tr>
        </table>
    </div>
</template>

<script>
export default {
    name: "Task2",
    data() {
        return {
            data: "",
            checked: false,
            dataList: [],
            selectedIndex: [],
            temp: 0
            };
        },
    methods: {
     addToList(){
         this.dataList.push(this.data);
     },
     selectedIndexes(index) {
         this.selectedIndex.push(index)
     },
     removeFromList() {
         let checkBoxNames = document.getElementsByName("checkBox");


            for(this.temp=0;this.temp<this.selectedIndex.length;this.temp++)
            {
                this.dataList[this.selectedIndex[this.temp]]="toDelete"
            }
            
            for(this.temp=0;this.temp<this.dataList.length;this.temp++)
            {
                if(this.dataList[this.temp]=="toDelete")
                {
                    this.dataList.splice(this.temp,1);
                    this.temp--;
                }
            }
            this.selectedIndex=[];

         for(let currentName in checkBoxNames)
           {
               if(currentName.checked)
                  currentName.checked = false;
           }
     }

    }
}

</script>



<style scoped>
div{
    color :black;
    background-color: blue;
}
</style>